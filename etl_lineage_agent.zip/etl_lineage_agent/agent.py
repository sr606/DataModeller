"""ETL lineage agent orchestrating parse -> graph -> analyze -> layout -> draw adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from analyzer.complexity_analyzer import ComplexityAnalyzer
from diagram.drawio_adapter import DrawCommand, DrawIOAdapter, DrawIOMcpClient
from layout.layout_engine import LayoutEngine
from llm.lineage_llm_client import LineageLlmClient
from lineage.graph_builder import LineageGraph, LineageGraphBuilder
from parser.pseudocode_parser import PseudocodeParser


@dataclass
class DiagramPlan:
    title: str
    graph: LineageGraph
    commands: List[DrawCommand]


class EtlLineageAgent:
    def __init__(self) -> None:
        llm_client = LineageLlmClient.from_env()
        self.parser = PseudocodeParser(llm_client=llm_client)
        self.builder = LineageGraphBuilder()
        self.analyzer = ComplexityAnalyzer()
        self.layout_engine = LayoutEngine()
        self.drawio_adapter = DrawIOAdapter()

    def generate_diagram_plans(self, pseudocode: str, diagram_title: str = "ETL Lineage") -> List[DiagramPlan]:
        parsed = self.parser.parse(pseudocode)
        graph = self.builder.build(parsed)
        decision = self.analyzer.analyze(len(graph.nodes))

        if decision.render_mode == "full_graph":
            computed = self.layout_engine.compute(graph, vertical_spacing=decision.vertical_spacing)
            commands = self.drawio_adapter.to_commands(computed, diagram_title)
            return [DiagramPlan(title=diagram_title, graph=computed, commands=commands)]

        if decision.render_mode == "split_by_pipeline":
            return self._split_by_pipeline(graph, decision.vertical_spacing, diagram_title)

        return self._split_by_stage_groups(graph, decision.vertical_spacing, diagram_title)

    def render(self, mcp: DrawIOMcpClient, pseudocode: str, diagram_title: str = "ETL Lineage") -> List[DiagramPlan]:
        plans = self.generate_diagram_plans(pseudocode=pseudocode, diagram_title=diagram_title)
        for plan in plans:
            self.drawio_adapter.render(mcp=mcp, graph=plan.graph, diagram_title=plan.title)
        return plans

    def _split_by_pipeline(self, graph: LineageGraph, spacing: int, title: str) -> List[DiagramPlan]:
        # Pipeline split by weakly connected components.
        node_map: Dict[str, int] = {node.id: idx for idx, node in enumerate(graph.nodes)}
        parent = list(range(len(graph.nodes)))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: int, b: int) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        for edge in graph.edges:
            if edge.from_node in node_map and edge.to_node in node_map:
                union(node_map[edge.from_node], node_map[edge.to_node])

        components: Dict[int, List[str]] = {}
        for node_id, idx in node_map.items():
            root = find(idx)
            components.setdefault(root, []).append(node_id)

        plans: List[DiagramPlan] = []
        for num, component_nodes in enumerate(components.values(), start=1):
            component_set = set(component_nodes)
            sub_nodes = [node for node in graph.nodes if node.id in component_set]
            sub_edges = [
                edge
                for edge in graph.edges
                if edge.from_node in component_set and edge.to_node in component_set
            ]
            sub_graph = LineageGraph(nodes=sub_nodes, edges=sub_edges)
            computed = self.layout_engine.compute(sub_graph, vertical_spacing=spacing)
            sub_title = f"{title} - Pipeline {num}"
            commands = self.drawio_adapter.to_commands(computed, sub_title)
            plans.append(DiagramPlan(title=sub_title, graph=computed, commands=commands))

        return plans

    def _split_by_stage_groups(self, graph: LineageGraph, spacing: int, title: str) -> List[DiagramPlan]:
        groups = {
            "Extract Layer": {"SOURCE"},
            "Transform Layer": {"TRANSFORM", "FILTER", "JOIN", "AGGREGATION"},
            "Load Layer": {"TARGET"},
        }

        plans: List[DiagramPlan] = []
        for group_name, types in groups.items():
            sub_nodes = [node for node in graph.nodes if node.type in types]
            node_ids = {node.id for node in sub_nodes}
            sub_edges = [
                edge
                for edge in graph.edges
                if edge.from_node in node_ids and edge.to_node in node_ids
            ]
            sub_graph = LineageGraph(nodes=sub_nodes, edges=sub_edges)
            computed = self.layout_engine.compute(sub_graph, vertical_spacing=spacing)
            sub_title = f"{title} - {group_name}"
            commands = self.drawio_adapter.to_commands(computed, sub_title)
            plans.append(DiagramPlan(title=sub_title, graph=computed, commands=commands))

        return plans
