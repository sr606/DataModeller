"""Graph model and lineage builder."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from parser.pseudocode_parser import ParsedPseudocode


@dataclass
class GraphNode:
    id: str
    label: str
    type: str
    layer: int = -1
    x: int = 0
    y: int = 0


@dataclass(frozen=True)
class GraphEdge:
    from_node: str
    to_node: str


@dataclass
class LineageGraph:
    nodes: List[GraphNode] = field(default_factory=list)
    edges: List[GraphEdge] = field(default_factory=list)

    def node_map(self) -> Dict[str, GraphNode]:
        return {node.id: node for node in self.nodes}

    def to_dict(self) -> dict:
        return {
            "nodes": [
                {
                    "id": node.id,
                    "label": node.label,
                    "type": node.type,
                    "layer": node.layer,
                    "x": node.x,
                    "y": node.y,
                }
                for node in self.nodes
            ],
            "edges": [
                {"from": edge.from_node, "to": edge.to_node}
                for edge in self.edges
            ],
        }


class LineageGraphBuilder:
    """Builds graph objects from parsed pseudocode output."""

    def build(self, parsed: ParsedPseudocode) -> LineageGraph:
        nodes = [
            GraphNode(
                id=stage.id,
                label=stage.label,
                type=stage.stage_type,
            )
            for stage in parsed.stages
        ]
        edges = [GraphEdge(from_node=edge.source, to_node=edge.target) for edge in parsed.edges]
        return LineageGraph(nodes=nodes, edges=edges)