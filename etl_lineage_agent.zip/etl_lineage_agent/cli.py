"""CLI entrypoint for ETL lineage generation and Draw.io MCP rendering."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import List, Tuple

from dotenv import load_dotenv

from agent import EtlLineageAgent
from diagram.drawio_mcp_client import DrawIOMcpDryRunClient, DrawIOMcpHttpClient


def _collect_inputs(args: argparse.Namespace) -> List[Tuple[str, str]]:
    if args.pseudocode:
        return [("inline", args.pseudocode)]

    if args.input_file:
        input_path = Path(args.input_file)
        with open(input_path, "r", encoding="utf-8") as f:
            return [(input_path.stem, f.read())]

    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        raise ValueError(f"Input directory does not exist: {input_dir}")

    files = sorted([p for p in input_dir.iterdir() if p.is_file()])
    if not files:
        raise ValueError(f"No input files found in: {input_dir}")

    payloads: List[Tuple[str, str]] = []
    for file_path in files:
        with open(file_path, "r", encoding="utf-8") as f:
            payloads.append((file_path.stem, f.read()))
    return payloads


def _write_json(path: str, payload: object) -> None:
    parent = Path(path).parent
    parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate ETL lineage graph from pseudocode and render through Draw.io MCP."
    )
    parser.add_argument("--input-file", help="Path to pseudocode text file.")
    parser.add_argument(
        "--input-dir",
        default="data/input",
        help="Directory containing pseudocode input files for batch processing.",
    )
    parser.add_argument(
        "--output-dir",
        default="data/output",
        help="Directory where output JSON files are written.",
    )
    parser.add_argument("--pseudocode", help="Inline pseudocode text.")
    parser.add_argument("--title", default="ETL Lineage", help="Diagram title.")
    parser.add_argument(
        "--render-mode",
        choices=["none", "dry-run", "http"],
        default="dry-run",
        help="Rendering mode: none, dry-run (local command log), or http (MCP bridge).",
    )
    return parser


def main() -> None:
    load_dotenv()
    args = build_parser().parse_args()
    inputs = _collect_inputs(args)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    agent = EtlLineageAgent()
    http_client = DrawIOMcpHttpClient.from_env() if args.render_mode == "http" else None
    is_multi_input = len(inputs) > 1

    for name, pseudocode in inputs:
        base_name = name or "input"
        title = args.title if not is_multi_input else f"{args.title} - {base_name}"
        plans = agent.generate_diagram_plans(pseudocode=pseudocode, diagram_title=title)

        graph_payload = [
            {"title": plan.title, "graph": plan.graph.to_dict()}
            for plan in plans
        ]
        command_payload = [
            {
                "title": plan.title,
                "commands": [
                    {"method": cmd.method, "payload": cmd.payload}
                    for cmd in plan.commands
                ],
            }
            for plan in plans
        ]

        _write_json(str(output_dir / f"{base_name}_graph.json"), graph_payload)
        _write_json(str(output_dir / f"{base_name}_commands.json"), command_payload)

        if args.render_mode == "none":
            continue

        if args.render_mode == "dry-run":
            env_output = os.getenv("DRAWIO_DRY_RUN_OUTPUT", "").strip()
            if env_output:
                if "{name}" in env_output:
                    dry_run_path = env_output.format(name=base_name)
                elif is_multi_input:
                    dry_run_path = str(output_dir / f"{base_name}_{Path(env_output).name}")
                else:
                    dry_run_path = env_output
            else:
                dry_run_path = str(output_dir / f"{base_name}_mcp_dry_run_commands.json")
            client = DrawIOMcpDryRunClient(output_path=dry_run_path)
        else:
            client = http_client

        for plan in plans:
            agent.drawio_adapter.render(client, plan.graph, plan.title)


if __name__ == "__main__":
    main()
