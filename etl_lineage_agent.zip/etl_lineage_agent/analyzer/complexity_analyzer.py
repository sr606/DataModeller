"""Complexity analyzer for ETL lineage rendering decisions."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ComplexityDecision:
    render_mode: str
    vertical_spacing: int


class ComplexityAnalyzer:
    """Decides rendering mode and spacing based on node count."""

    def analyze(self, node_count: int) -> ComplexityDecision:
        if node_count < 50:
            mode = "full_graph"
        elif node_count < 150:
            mode = "split_by_pipeline"
        else:
            mode = "split_by_stage_groups"

        if node_count > 200:
            spacing = 80
        elif node_count > 100:
            spacing = 120
        else:
            spacing = 160

        return ComplexityDecision(render_mode=mode, vertical_spacing=spacing)