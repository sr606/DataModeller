"""Pseudocode parser for ETL lineage extraction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List

from llm.lineage_llm_client import LineageLlmClient


@dataclass(frozen=True)
class ParsedStage:
    id: str
    label: str
    stage_type: str


@dataclass(frozen=True)
class ParsedEdge:
    source: str
    target: str


@dataclass(frozen=True)
class ParsedPseudocode:
    stages: List[ParsedStage]
    edges: List[ParsedEdge]


class PseudocodeParser:
    """Parses ETL pseudocode using mandatory LLM extraction and classification."""

    _VALID_TYPES = {"SOURCE", "TRANSFORM", "JOIN", "FILTER", "AGGREGATION", "TARGET"}

    def __init__(self, llm_client: LineageLlmClient) -> None:
        self.llm_client = llm_client

    def parse(self, pseudocode: str) -> ParsedPseudocode:
        extracted = self.llm_client.extract_stages_and_edges(pseudocode)
        ordered_stages = sorted(extracted["stages"], key=lambda s: s.order)
        stage_names = [stage.name for stage in ordered_stages]
        classifications = self.llm_client.classify_stages(stage_names)

        stages: List[ParsedStage] = []
        id_by_name: dict[str, str] = {}
        for index, stage in enumerate(ordered_stages, start=1):
            stage_id = self._to_id(stage.name, index)
            stage_type = classifications.get(stage.name, "TRANSFORM").upper()
            if stage_type not in self._VALID_TYPES:
                stage_type = "TRANSFORM"
            stages.append(ParsedStage(id=stage_id, label=stage.name, stage_type=stage_type))
            id_by_name.setdefault(stage.name, stage_id)

        edges: List[ParsedEdge] = []
        for edge in extracted["edges"]:
            source_id = id_by_name.get(edge.source)
            target_id = id_by_name.get(edge.target)
            if source_id and target_id:
                edges.append(ParsedEdge(source=source_id, target=target_id))

        return ParsedPseudocode(stages=stages, edges=edges)

    def _to_id(self, label: str, index: int) -> str:
        base = re.sub(r"[^a-zA-Z0-9_\-]", "", label.replace(" ", "_")).lower()
        if not base:
            base = f"stage_{index}"
        return f"{base}_{index}"
