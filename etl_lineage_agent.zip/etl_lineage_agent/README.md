# ETL Lineage Agent

Generates ETL lineage diagrams from pseudocode.

Architecture:
- LLM -> stage extraction
- LLM -> stage type classification
- Graph builder
- Complexity analyzer
- Layout engine (agent computes x/y)
- Draw.io adapter
- Draw.io MCP renderer

## Linux Setup

```bash
cd etl_lineage_agent
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Update `.env` values as needed.

## Data Folders

- Put pseudocode input files in `data/input`.
- Generated output files are written to `data/output`.

## Run

### 1) Dry-run (recommended first)
This does not call MCP server. It writes computed graph and commands to JSON.

```bash
python cli.py --input-dir data/input --output-dir data/output --title "ETL Lineage" --render-mode dry-run
```

For each input file, outputs are created in `data/output`:
- `<file>_graph.json`
- `<file>_commands.json`
- `<file>_mcp_dry_run_commands.json` (if `DRAWIO_DRY_RUN_OUTPUT` uses `{name}`)

### 2) HTTP MCP rendering
Use this when your Draw.io MCP bridge is running.

```bash
python cli.py --input-dir data/input --output-dir data/output --title "ETL Lineage" --render-mode http
```

### 3) Single file input (optional)

```bash
python cli.py --input-file data/input/sample_pseudocode.txt --output-dir data/output --title "ETL Lineage" --render-mode dry-run
```

## Environment Variables

- `DRAWIO_DRY_RUN_OUTPUT`: Output file for dry-run emitted MCP commands. Supports `{name}` for batch mode.
- `DRAWIO_MCP_BASE_URL`: MCP bridge base URL. Required for `--render-mode http`.
- `DRAWIO_MCP_API_KEY`: Optional bearer token.
- `DRAWIO_MCP_CALL_PATH`: Tool call path. Default `/mcp/call`.
- `DRAWIO_MCP_TIMEOUT_SECONDS`: HTTP timeout in seconds.
- `DRAWIO_MCP_TOOL_CREATE_DIAGRAM`: MCP tool name for diagram creation.
- `DRAWIO_MCP_TOOL_ADD_SHAPE`: MCP tool name for shape insertion.
- `DRAWIO_MCP_TOOL_CONNECT`: MCP tool name for connectors.
- `AZURE_OPENAI_ENDPOINT`: Azure OpenAI endpoint (for example `https://<resource>.openai.azure.com`).
- `AZURE_OPENAI_API_KEY`: Required Azure OpenAI API key.
- `AZURE_OPENAI_DEPLOYMENT`: Required Azure OpenAI deployment name.
- `AZURE_OPENAI_API_VERSION`: Azure OpenAI API version (default `2024-10-21`).
- `AZURE_OPENAI_TIMEOUT_SECONDS`: Timeout for Azure OpenAI API calls.

## Where LLM Is Bound And Called

- Binding (env -> client): `LineageLlmClient.from_env()` in [agent.py](/c:/Users/SHRADDHA/Downloads/etl_lineage_agent/agent.py)
- LLM client implementation: [llm/lineage_llm_client.py](/c:/Users/SHRADDHA/Downloads/etl_lineage_agent/llm/lineage_llm_client.py)
- LLM call 1 (extract stages/edges): `extract_stages_and_edges(...)` in [parser/pseudocode_parser.py](/c:/Users/SHRADDHA/Downloads/etl_lineage_agent/parser/pseudocode_parser.py)
- LLM call 2 (classify stage types): `classify_stages(...)` in [parser/pseudocode_parser.py](/c:/Users/SHRADDHA/Downloads/etl_lineage_agent/parser/pseudocode_parser.py)

## Notes for Linux vs Windows

- The code is OS-agnostic Python and works on Linux.
- Use `python3` and Linux venv activation command (`source .venv/bin/activate`).
- No Windows-only paths or APIs are required.
