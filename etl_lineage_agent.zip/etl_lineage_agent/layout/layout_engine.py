"""Layout engine assigning layers and coordinates."""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List

from lineage.graph_builder import LineageGraph


class LayoutEngine:
    """Computes ETL node layers and 2D positions before Draw.io rendering."""

    _LAYER_BY_TYPE = {
        "SOURCE": 0,
        "FILTER": 1,
        "JOIN": 1,
        "AGGREGATION": 1,
        "TRANSFORM": 1,
        "TARGET": 2,
    }

    _X_BY_LAYER = {
        0: 100,
        1: 400,
        2: 700,
    }

    def compute(self, graph: LineageGraph, vertical_spacing: int = 160, top_padding: int = 120) -> LineageGraph:
        grouped: Dict[int, List] = defaultdict(list)

        for node in graph.nodes:
            node.layer = self._LAYER_BY_TYPE.get(node.type, 1)
            grouped[node.layer].append(node)

        for layer, nodes_in_layer in grouped.items():
            x = self._X_BY_LAYER.get(layer, 400 + (layer - 1) * 300)
            for order, node in enumerate(nodes_in_layer):
                node.x = x
                node.y = top_padding + order * vertical_spacing

        return graph