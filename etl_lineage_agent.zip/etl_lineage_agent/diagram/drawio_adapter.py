"""Draw.io adapter converting lineage graph into MCP draw commands."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Protocol

from lineage.graph_builder import LineageGraph


class DrawIOMcpClient(Protocol):
    def create_diagram(self, title: str) -> None: ...
    def add_shape(self, shape: str, label: str, x: int, y: int) -> None: ...
    def connect(self, source: str, target: str) -> None: ...


@dataclass(frozen=True)
class DrawCommand:
    method: str
    payload: dict


class DrawIOAdapter:
    """Maps ETL graph semantics to draw.io-compatible MCP commands."""

    shape_map = {
        "SOURCE": "database",
        "TRANSFORM": "rectangle",
        "JOIN": "diamond",
        "FILTER": "parallelogram",
        "AGGREGATION": "hexagon",
        "TARGET": "database",
    }

    def to_commands(self, graph: LineageGraph, diagram_title: str) -> List[DrawCommand]:
        commands: List[DrawCommand] = [
            DrawCommand(method="create_diagram", payload={"title": diagram_title})
        ]

        for node in graph.nodes:
            shape = self.shape_map.get(node.type, "rectangle")
            commands.append(
                DrawCommand(
                    method="add_shape",
                    payload={
                        "shape": shape,
                        "label": node.label,
                        "x": node.x,
                        "y": node.y,
                    },
                )
            )

        node_lookup = {node.id: node for node in graph.nodes}
        for edge in graph.edges:
            if edge.from_node in node_lookup and edge.to_node in node_lookup:
                commands.append(
                    DrawCommand(
                        method="connect",
                        payload={
                            "source": node_lookup[edge.from_node].label,
                            "target": node_lookup[edge.to_node].label,
                        },
                    )
                )

        return commands

    def render(self, mcp: DrawIOMcpClient, graph: LineageGraph, diagram_title: str) -> None:
        commands = self.to_commands(graph=graph, diagram_title=diagram_title)
        for command in commands:
            getattr(mcp, command.method)(**command.payload)