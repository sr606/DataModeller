"""Concrete Draw.io MCP clients.

This module provides:
1) A dry-run client for local validation.
2) An HTTP MCP bridge client for real rendering.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx


@dataclass
class DrawIOMcpDryRunClient:
    """Collects draw commands locally instead of calling MCP."""

    output_path: Optional[str] = None
    commands: List[Dict[str, Any]] = field(default_factory=list)

    def create_diagram(self, title: str) -> None:
        self.commands.append({"tool": "create_diagram", "arguments": {"title": title}})
        self._flush()

    def add_shape(self, shape: str, label: str, x: int, y: int) -> None:
        self.commands.append(
            {
                "tool": "add_shape",
                "arguments": {"shape": shape, "label": label, "x": x, "y": y},
            }
        )
        self._flush()

    def connect(self, source: str, target: str) -> None:
        self.commands.append(
            {"tool": "connect", "arguments": {"source": source, "target": target}}
        )
        self._flush()

    def _flush(self) -> None:
        if not self.output_path:
            return
        with open(self.output_path, "w", encoding="utf-8") as f:
            json.dump(self.commands, f, indent=2)


class DrawIOMcpHttpClient:
    """Calls a Draw.io MCP bridge over HTTP.

    Expected request format:
    POST {base_url}{call_path}
    {
      "tool": "<tool_name>",
      "arguments": { ... }
    }
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        call_path: str = "/mcp/call",
        tool_create_diagram: str = "drawio.create_diagram",
        tool_add_shape: str = "drawio.add_shape",
        tool_connect: str = "drawio.connect",
        timeout_seconds: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.call_path = call_path
        self.tool_create_diagram = tool_create_diagram
        self.tool_add_shape = tool_add_shape
        self.tool_connect = tool_connect
        self._client = httpx.Client(timeout=timeout_seconds)

    @classmethod
    def from_env(cls) -> "DrawIOMcpHttpClient":
        base_url = os.getenv("DRAWIO_MCP_BASE_URL", "").strip()
        if not base_url:
            raise ValueError("DRAWIO_MCP_BASE_URL is required for HTTP render mode.")

        return cls(
            base_url=base_url,
            api_key=os.getenv("DRAWIO_MCP_API_KEY", "").strip(),
            call_path=os.getenv("DRAWIO_MCP_CALL_PATH", "/mcp/call").strip(),
            tool_create_diagram=os.getenv(
                "DRAWIO_MCP_TOOL_CREATE_DIAGRAM", "drawio.create_diagram"
            ).strip(),
            tool_add_shape=os.getenv(
                "DRAWIO_MCP_TOOL_ADD_SHAPE", "drawio.add_shape"
            ).strip(),
            tool_connect=os.getenv("DRAWIO_MCP_TOOL_CONNECT", "drawio.connect").strip(),
            timeout_seconds=float(os.getenv("DRAWIO_MCP_TIMEOUT_SECONDS", "30")),
        )

    def create_diagram(self, title: str) -> None:
        self._call_tool(self.tool_create_diagram, {"title": title})

    def add_shape(self, shape: str, label: str, x: int, y: int) -> None:
        self._call_tool(
            self.tool_add_shape,
            {"shape": shape, "label": label, "x": x, "y": y},
        )

    def connect(self, source: str, target: str) -> None:
        self._call_tool(self.tool_connect, {"source": source, "target": target})

    def _call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> None:
        url = f"{self.base_url}{self.call_path}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {"tool": tool_name, "arguments": arguments}
        response = self._client.post(url, headers=headers, json=payload)
        response.raise_for_status()

