"""LLM client for ETL pseudocode extraction and stage classification."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List

import httpx


@dataclass(frozen=True)
class ExtractedStage:
    name: str
    order: int


@dataclass(frozen=True)
class ExtractedEdge:
    source: str
    target: str


class LineageLlmClient:
    """Calls Azure OpenAI chat completions for ETL lineage extraction."""

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        deployment: str,
        api_version: str,
        timeout_seconds: float = 60.0,
    ) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.api_key = api_key.strip()
        self.deployment = deployment.strip()
        self.api_version = api_version.strip()
        self._client = httpx.Client(timeout=timeout_seconds)

        if not self.endpoint:
            raise ValueError("AZURE_OPENAI_ENDPOINT is required.")
        if not self.api_key:
            raise ValueError("AZURE_OPENAI_API_KEY is required.")
        if not self.deployment:
            raise ValueError("AZURE_OPENAI_DEPLOYMENT is required.")
        if not self.api_version:
            raise ValueError("AZURE_OPENAI_API_VERSION is required.")

    @classmethod
    def from_env(cls) -> "LineageLlmClient":
        return cls(
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", ""),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
            timeout_seconds=float(os.getenv("AZURE_OPENAI_TIMEOUT_SECONDS", "60")),
        )

    def extract_stages_and_edges(self, pseudocode: str) -> Dict[str, List]:
        system_prompt = (
            "You extract ETL lineage from pseudocode. "
            "Return strict JSON only with keys: stages, edges. "
            "stages: array of {name, order}. edges: array of {source, target}. "
            "Keep order starting at 1."
        )
        user_prompt = f"Pseudocode:\n{pseudocode}"
        payload = self._chat(system_prompt, user_prompt)

        stages_raw = payload.get("stages", [])
        edges_raw = payload.get("edges", [])

        stages = [
            ExtractedStage(name=str(item["name"]).strip(), order=int(item["order"]))
            for item in stages_raw
            if isinstance(item, dict) and "name" in item and "order" in item
        ]
        edges = [
            ExtractedEdge(
                source=str(item["source"]).strip(),
                target=str(item["target"]).strip(),
            )
            for item in edges_raw
            if isinstance(item, dict) and "source" in item and "target" in item
        ]
        return {"stages": stages, "edges": edges}

    def classify_stages(self, stage_names: List[str]) -> Dict[str, str]:
        system_prompt = (
            "Classify ETL stage names into one of these types only: "
            "SOURCE, TRANSFORM, JOIN, FILTER, AGGREGATION, TARGET. "
            "Return strict JSON only with key classifications as array of "
            "{name, type}."
        )
        user_prompt = "Stage names:\n" + json.dumps(stage_names, indent=2)
        payload = self._chat(system_prompt, user_prompt)

        result: Dict[str, str] = {}
        for item in payload.get("classifications", []):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "")).strip()
            stage_type = str(item.get("type", "TRANSFORM")).strip().upper()
            if name:
                result[name] = stage_type
        return result

    def _chat(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        url = (
            f"{self.endpoint}/openai/deployments/{self.deployment}/chat/completions"
            f"?api-version={self.api_version}"
        )
        headers = {
            "api-key": self.api_key,
            "Content-Type": "application/json",
        }
        body = {
            "temperature": 0,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": {"type": "json_object"},
        }
        response = self._client.post(url, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()
        content = data["choices"][0]["message"]["content"]
        return json.loads(content)
